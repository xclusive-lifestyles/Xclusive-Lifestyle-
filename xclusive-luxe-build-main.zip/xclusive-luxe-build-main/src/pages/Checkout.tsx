import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Textarea } from '@/components/ui/textarea';
import { useCart } from '@/contexts/CartContext';
import { coupons } from '@/data/products';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { Tag, CreditCard, Smartphone, Building2 } from 'lucide-react';

const Checkout = () => {
  const navigate = useNavigate();
  const { cart, totalPrice, clearCart } = useCart();
  const [couponCode, setCouponCode] = useState('');
  const [discount, setDiscount] = useState(0);
  const [appliedCoupon, setAppliedCoupon] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('cod');

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    pincode: '',
  });

  const handleApplyCoupon = () => {
    const coupon = coupons.find(
      (c) => c.code.toUpperCase() === couponCode.toUpperCase()
    );
    if (coupon) {
      const discountAmount = (totalPrice * coupon.discount) / 100;
      setDiscount(discountAmount);
      setAppliedCoupon(coupon.code);
      toast.success(`Coupon applied! ${coupon.discount}% off`);
    } else {
      toast.error('Invalid coupon code');
    }
  };

  const handleRemoveCoupon = () => {
    setDiscount(0);
    setAppliedCoupon('');
    setCouponCode('');
    toast.info('Coupon removed');
  };

  const finalTotal = totalPrice - discount;

  // Apply online payment discount (5%)
  const onlineDiscount = paymentMethod !== 'cod' ? finalTotal * 0.05 : 0;
  const totalWithPaymentDiscount = finalTotal - onlineDiscount;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validate form
    if (!formData.name || !formData.email || !formData.phone || !formData.address) {
      toast.error('Please fill all required fields');
      return;
    }

    // Generate order ID
    const orderId = `XL${Date.now()}`;

    // Calculate delivery date (5-8 days)
    const deliveryDate = new Date();
    deliveryDate.setDate(deliveryDate.getDate() + Math.floor(Math.random() * 4) + 5);

    // Prepare order details
    const orderDetails = {
      orderId,
      customerName: formData.name,
      email: formData.email,
      phone: formData.phone,
      address: `${formData.address}, ${formData.city}, ${formData.pincode}`,
      items: cart.map((item) => ({
        name: item.name,
        quantity: item.quantity,
        price: item.price,
      })),
      subtotal: totalPrice,
      discount: discount + onlineDiscount,
      total: totalWithPaymentDiscount,
      paymentMethod:
        paymentMethod === 'cod'
          ? 'Cash on Delivery'
          : paymentMethod === 'upi'
          ? 'UPI Payment'
          : 'Net Banking',
      deliveryDate: deliveryDate.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      }),
    };

    // Store order details in session storage
    sessionStorage.setItem('lastOrder', JSON.stringify(orderDetails));

    // Clear cart
    clearCart();

    // Navigate to confirmation page
    navigate('/order-confirmation');
  };

  if (cart.length === 0) {
    navigate('/cart');
    return null;
  }

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="font-display text-4xl font-bold mb-8"
        >
          Checkout
        </motion.h1>

        <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Form Section */}
          <div className="lg:col-span-2 space-y-6">
            {/* Customer Details */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-card border border-border rounded-lg p-6"
            >
              <h2 className="font-display text-2xl font-bold mb-6">
                Customer Details
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    required
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    placeholder="Enter your full name"
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) =>
                      setFormData({ ...formData, email: e.target.value })
                    }
                    placeholder="your@email.com"
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input
                    id="phone"
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) =>
                      setFormData({ ...formData, phone: e.target.value })
                    }
                    placeholder="+91 98765 43210"
                  />
                </div>
                <div className="md:col-span-2">
                  <Label htmlFor="address">Address *</Label>
                  <Textarea
                    id="address"
                    required
                    value={formData.address}
                    onChange={(e) =>
                      setFormData({ ...formData, address: e.target.value })
                    }
                    placeholder="Enter your complete address"
                    rows={3}
                  />
                </div>
                <div>
                  <Label htmlFor="city">City *</Label>
                  <Input
                    id="city"
                    required
                    value={formData.city}
                    onChange={(e) =>
                      setFormData({ ...formData, city: e.target.value })
                    }
                    placeholder="City"
                  />
                </div>
                <div>
                  <Label htmlFor="pincode">Pincode *</Label>
                  <Input
                    id="pincode"
                    required
                    value={formData.pincode}
                    onChange={(e) =>
                      setFormData({ ...formData, pincode: e.target.value })
                    }
                    placeholder="400001"
                  />
                </div>
              </div>
            </motion.div>

            {/* Payment Method */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-card border border-border rounded-lg p-6"
            >
              <h2 className="font-display text-2xl font-bold mb-6">
                Payment Method
              </h2>
              <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
                <div className="space-y-3">
                  <Label
                    htmlFor="cod"
                    className="flex items-center space-x-3 p-4 border-2 border-border rounded-lg cursor-pointer hover:border-primary transition-colors"
                  >
                    <RadioGroupItem value="cod" id="cod" />
                    <CreditCard className="h-5 w-5 text-muted-foreground" />
                    <div className="flex-1">
                      <span className="font-semibold">Cash on Delivery</span>
                    </div>
                  </Label>
                  <Label
                    htmlFor="upi"
                    className="flex items-center space-x-3 p-4 border-2 border-border rounded-lg cursor-pointer hover:border-primary transition-colors"
                  >
                    <RadioGroupItem value="upi" id="upi" />
                    <Smartphone className="h-5 w-5 text-muted-foreground" />
                    <div className="flex-1">
                      <span className="font-semibold">UPI Payment</span>
                      <p className="text-sm text-accent">Extra 5% off</p>
                    </div>
                  </Label>
                  <Label
                    htmlFor="netbanking"
                    className="flex items-center space-x-3 p-4 border-2 border-border rounded-lg cursor-pointer hover:border-primary transition-colors"
                  >
                    <RadioGroupItem value="netbanking" id="netbanking" />
                    <Building2 className="h-5 w-5 text-muted-foreground" />
                    <div className="flex-1">
                      <span className="font-semibold">Net Banking</span>
                      <p className="text-sm text-accent">Extra 5% off</p>
                    </div>
                  </Label>
                </div>
              </RadioGroup>
            </motion.div>
          </div>

          {/* Order Summary */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-1"
          >
            <div className="bg-card border border-border rounded-lg p-6 sticky top-24">
              <h2 className="font-display text-2xl font-bold mb-6">
                Order Summary
              </h2>

              {/* Coupon */}
              <div className="mb-6">
                <Label>Apply Coupon</Label>
                <div className="flex gap-2 mt-2">
                  <Input
                    placeholder="Enter coupon code"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    disabled={!!appliedCoupon}
                  />
                  {appliedCoupon ? (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={handleRemoveCoupon}
                    >
                      Remove
                    </Button>
                  ) : (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={handleApplyCoupon}
                    >
                      Apply
                    </Button>
                  )}
                </div>
                {appliedCoupon && (
                  <p className="text-sm text-accent mt-2 flex items-center gap-1">
                    <Tag className="h-4 w-4" />
                    {appliedCoupon} applied
                  </p>
                )}
              </div>

              {/* Price Breakdown */}
              <div className="space-y-3 mb-6">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>₹{totalPrice.toLocaleString('en-IN')}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-accent">
                    <span>Coupon Discount</span>
                    <span>-₹{discount.toLocaleString('en-IN')}</span>
                  </div>
                )}
                {onlineDiscount > 0 && (
                  <div className="flex justify-between text-accent">
                    <span>Online Payment Bonus</span>
                    <span>-₹{onlineDiscount.toLocaleString('en-IN')}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Delivery</span>
                  <span className="text-accent">FREE</span>
                </div>
                <div className="border-t border-border pt-3">
                  <div className="flex justify-between text-lg font-bold">
                    <span>Total</span>
                    <span className="text-accent">
                      ₹{totalWithPaymentDiscount.toLocaleString('en-IN')}
                    </span>
                  </div>
                </div>
              </div>

              {/* Items */}
              <div className="border-t border-border pt-4 mb-6">
                <p className="text-sm text-muted-foreground mb-3">
                  {cart.length} {cart.length === 1 ? 'item' : 'items'}
                </p>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {cart.map((item) => (
                    <div key={item.id} className="flex justify-between text-sm">
                      <span className="line-clamp-1 flex-1">
                        {item.name} x{item.quantity}
                      </span>
                      <span className="font-semibold ml-2">
                        ₹{(item.price * item.quantity).toLocaleString('en-IN')}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <Button type="submit" variant="accent" size="lg" className="w-full">
                Place Order
              </Button>
            </div>
          </motion.div>
        </form>
      </div>
    </div>
  );
};

export default Checkout;
