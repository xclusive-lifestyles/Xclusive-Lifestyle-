import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { CheckCircle, Package, Truck, Home } from 'lucide-react';
import { motion } from 'framer-motion';
import DeliveryAnimation from '@/components/DeliveryAnimation';
import InvoiceModal from '@/components/InvoiceModal';

const OrderConfirmation = () => {
  const navigate = useNavigate();
  const [showAnimation, setShowAnimation] = useState(true);
  const [showInvoice, setShowInvoice] = useState(false);
  const [orderDetails, setOrderDetails] = useState<any>(null);

  useEffect(() => {
    const savedOrder = sessionStorage.getItem('lastOrder');
    if (!savedOrder) {
      navigate('/');
      return;
    }
    setOrderDetails(JSON.parse(savedOrder));
  }, [navigate]);

  if (!orderDetails) return null;

  return (
    <>
      {showAnimation && (
        <DeliveryAnimation onComplete={() => setShowAnimation(false)} />
      )}

      <div className="min-h-screen py-12">
        <div className="container mx-auto px-4 max-w-3xl">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <CheckCircle className="h-24 w-24 text-accent mx-auto mb-6" />
            <h1 className="font-display text-4xl md:text-5xl font-bold mb-4">
              Order Confirmed! 🎉
            </h1>
            <p className="text-xl text-muted-foreground mb-2">
              Thank you for your purchase, {orderDetails.customerName}!
            </p>
            <p className="text-accent font-semibold">
              Order ID: {orderDetails.orderId}
            </p>
          </motion.div>

          {/* Order Status Timeline */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-card border border-border rounded-lg p-6 mb-8"
          >
            <h2 className="font-display text-2xl font-bold mb-6">Order Status</h2>
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center">
                  <CheckCircle className="h-5 w-5 text-accent" />
                </div>
                <div>
                  <p className="font-semibold">Order Confirmed</p>
                  <p className="text-sm text-muted-foreground">
                    Your order has been received and confirmed
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4 opacity-50">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                  <Package className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-semibold">Processing</p>
                  <p className="text-sm text-muted-foreground">
                    Your order is being prepared
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4 opacity-50">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                  <Truck className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-semibold">Out for Delivery</p>
                  <p className="text-sm text-muted-foreground">
                    Expected by {orderDetails.deliveryDate}
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Order Details */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-card border border-border rounded-lg p-6 mb-8"
          >
            <h2 className="font-display text-2xl font-bold mb-6">Order Details</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Delivery Address</p>
                  <p className="font-semibold">{orderDetails.address}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Payment Method</p>
                  <p className="font-semibold">{orderDetails.paymentMethod}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Amount</p>
                  <p className="text-xl font-bold text-accent">
                    ₹{orderDetails.total.toLocaleString('en-IN')}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Expected Delivery</p>
                  <p className="font-semibold text-accent">
                    {orderDetails.deliveryDate}
                  </p>
                </div>
              </div>

              <div className="border-t border-border pt-4">
                <p className="text-sm text-muted-foreground mb-2">Items</p>
                {orderDetails.items.map((item: any, index: number) => (
                  <div
                    key={index}
                    className="flex justify-between py-2 text-sm"
                  >
                    <span>
                      {item.name} x{item.quantity}
                    </span>
                    <span className="font-semibold">
                      ₹{(item.price * item.quantity).toLocaleString('en-IN')}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Actions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="flex flex-col sm:flex-row gap-4"
          >
            <Button
              onClick={() => setShowInvoice(true)}
              variant="accent"
              size="lg"
              className="flex-1"
            >
              View Invoice
            </Button>
            <Link to="/" className="flex-1">
              <Button variant="outline" size="lg" className="w-full">
                <Home className="mr-2 h-4 w-4" />
                Back to Home
              </Button>
            </Link>
          </motion.div>

          {/* Additional Info */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="mt-8 text-center text-sm text-muted-foreground"
          >
            <p>
              A confirmation email has been sent to{' '}
              <span className="text-accent font-semibold">{orderDetails.email}</span>
            </p>
            <p className="mt-2">
              For any queries, contact us at{' '}
              <span className="text-accent">+91 98765 43210</span>
            </p>
          </motion.div>
        </div>
      </div>

      {showInvoice && (
        <InvoiceModal
          open={showInvoice}
          onClose={() => setShowInvoice(false)}
          orderDetails={orderDetails}
        />
      )}
    </>
  );
};

export default OrderConfirmation;
