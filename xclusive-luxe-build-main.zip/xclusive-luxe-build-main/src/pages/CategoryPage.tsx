import { useParams } from 'react-router-dom';
import ProductCard from '@/components/ProductCard';
import { products, categories } from '@/data/products';
import { motion } from 'framer-motion';

const CategoryPage = () => {
  const { categoryId } = useParams();
  
  const category = categories.find((cat) => cat.id === categoryId);
  const filteredProducts =
    categoryId === 'all'
      ? products
      : products.filter((product) => product.category === categoryId);

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="font-display text-4xl md:text-5xl font-bold mb-4">
            {category?.icon} {category?.name}
          </h1>
          <p className="text-muted-foreground text-lg">
            {filteredProducts.length} products available
          </p>
        </motion.div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product, index) => (
            <ProductCard
              key={product.id}
              product={product}
              delay={index * 0.05}
            />
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-20">
            <p className="text-2xl text-muted-foreground">
              No products found in this category
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CategoryPage;
