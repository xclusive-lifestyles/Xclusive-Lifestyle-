import { Link } from 'react-router-dom';
import { ShoppingCart, Heart, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useCart } from '@/contexts/CartContext';
import { useWishlist } from '@/contexts/WishlistContext';
import { Badge } from '@/components/ui/badge';
import { categories } from '@/data/products';

const Header = () => {
  const { totalItems } = useCart();
  const { wishlist } = useWishlist();

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
      <div className="container mx-auto px-4">
        {/* Top Bar */}
        <div className="flex h-20 items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2 group">
            <div className="relative">
              <h1 className="font-display text-3xl font-bold bg-gradient-button bg-clip-text text-transparent group-hover:scale-105 transition-transform">
                Xclusive
              </h1>
              <p className="text-xs text-accent font-light tracking-wider">LIFESTYLES</p>
            </div>
          </Link>

          {/* Search Bar */}
          <div className="hidden md:flex flex-1 max-w-xl mx-8">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search for luxury products..."
                className="pl-10 bg-muted/50 border-border"
              />
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-4">
            <Link to="/wishlist">
              <Button variant="ghost" size="icon" className="relative">
                <Heart className="h-5 w-5" />
                {wishlist.length > 0 && (
                  <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-accent text-accent-foreground">
                    {wishlist.length}
                  </Badge>
                )}
              </Button>
            </Link>
            <Link to="/cart">
              <Button variant="ghost" size="icon" className="relative">
                <ShoppingCart className="h-5 w-5" />
                {totalItems > 0 && (
                  <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-accent text-accent-foreground">
                    {totalItems}
                  </Badge>
                )}
              </Button>
            </Link>
          </div>
        </div>

        {/* Categories */}
        <nav className="flex gap-1 py-3 overflow-x-auto scrollbar-hide border-t border-border/50">
          {categories.map((category) => (
            <Link key={category.id} to={`/category/${category.id}`}>
              <Button
                variant="ghost"
                size="sm"
                className="whitespace-nowrap hover:bg-primary/10 hover:text-accent"
              >
                <span className="mr-1">{category.icon}</span>
                {category.name}
              </Button>
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
};

export default Header;
