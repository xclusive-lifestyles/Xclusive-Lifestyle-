import { motion } from 'framer-motion';
import { Sparkles, Percent } from 'lucide-react';

const SalesBanner = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-accent py-3 text-center overflow-hidden relative"
    >
      <div className="container mx-auto px-4 flex items-center justify-center gap-3 relative z-10">
        <Sparkles className="h-5 w-5 animate-pulse" />
        <p className="text-sm md:text-base font-semibold text-accent-foreground">
          🎉 Limited Time Offer: Use{' '}
          <span className="font-bold">EXCLUSIVE15</span> for 15% off on orders above ₹3000
        </p>
        <Percent className="h-5 w-5 animate-pulse" />
      </div>
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent animate-shimmer"></div>
    </motion.div>
  );
};

export default SalesBanner;
