import { useEffect, useState } from 'react';
import { Truck } from 'lucide-react';

const DeliveryAnimation = ({ onComplete }: { onComplete: () => void }) => {
  const [show, setShow] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShow(false);
      onComplete();
    }, 3000);

    return () => clearTimeout(timer);
  }, [onComplete]);

  if (!show) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm">
      <div className="relative w-full h-32 overflow-hidden">
        <div className="animate-delivery">
          <Truck className="h-16 w-16 text-accent" />
        </div>
      </div>
      <div className="absolute bottom-1/3 text-center">
        <p className="text-2xl font-display font-bold text-accent">
          Order Confirmed! 🎉
        </p>
        <p className="text-muted-foreground mt-2">
          Your order is on its way...
        </p>
      </div>
    </div>
  );
};

export default DeliveryAnimation;
