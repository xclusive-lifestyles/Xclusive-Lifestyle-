import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Download, X } from 'lucide-react';

interface OrderDetails {
  orderId: string;
  customerName: string;
  email: string;
  phone: string;
  address: string;
  items: Array<{ name: string; quantity: number; price: number }>;
  subtotal: number;
  discount: number;
  total: number;
  paymentMethod: string;
  deliveryDate: string;
}

interface InvoiceModalProps {
  open: boolean;
  onClose: () => void;
  orderDetails: OrderDetails;
}

const InvoiceModal = ({ open, onClose, orderDetails }: InvoiceModalProps) => {
  const handlePrint = () => {
    window.print();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">Order Invoice</DialogTitle>
        </DialogHeader>

        <div className="space-y-6 print:text-black" id="invoice">
          {/* Header */}
          <div className="text-center border-b border-border pb-4">
            <h1 className="font-display text-3xl font-bold text-accent">
              Xclusive Lifestyles
            </h1>
            <p className="text-sm text-muted-foreground">
              Premium Luxury Shopping
            </p>
          </div>

          {/* Order Info */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">Order ID</p>
              <p className="font-semibold">{orderDetails.orderId}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Order Date</p>
              <p className="font-semibold">
                {new Date().toLocaleDateString('en-IN')}
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Expected Delivery</p>
              <p className="font-semibold text-accent">{orderDetails.deliveryDate}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Payment Method</p>
              <p className="font-semibold">{orderDetails.paymentMethod}</p>
            </div>
          </div>

          {/* Customer Details */}
          <div className="border-t border-border pt-4">
            <h3 className="font-semibold mb-2">Customer Details</h3>
            <div className="space-y-1 text-sm">
              <p><span className="text-muted-foreground">Name:</span> {orderDetails.customerName}</p>
              <p><span className="text-muted-foreground">Email:</span> {orderDetails.email}</p>
              <p><span className="text-muted-foreground">Phone:</span> {orderDetails.phone}</p>
              <p><span className="text-muted-foreground">Address:</span> {orderDetails.address}</p>
            </div>
          </div>

          {/* Items */}
          <div className="border-t border-border pt-4">
            <h3 className="font-semibold mb-3">Order Items</h3>
            <div className="space-y-2">
              {orderDetails.items.map((item, index) => (
                <div
                  key={index}
                  className="flex justify-between items-center py-2 border-b border-border/50"
                >
                  <div>
                    <p className="font-medium">{item.name}</p>
                    <p className="text-sm text-muted-foreground">
                      Qty: {item.quantity}
                    </p>
                  </div>
                  <p className="font-semibold">
                    ₹{(item.price * item.quantity).toLocaleString('en-IN')}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Totals */}
          <div className="border-t border-border pt-4 space-y-2">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Subtotal</span>
              <span>₹{orderDetails.subtotal.toLocaleString('en-IN')}</span>
            </div>
            {orderDetails.discount > 0 && (
              <div className="flex justify-between text-accent">
                <span>Discount</span>
                <span>-₹{orderDetails.discount.toLocaleString('en-IN')}</span>
              </div>
            )}
            <div className="flex justify-between text-lg font-bold border-t border-border pt-2">
              <span>Total</span>
              <span className="text-accent">
                ₹{orderDetails.total.toLocaleString('en-IN')}
              </span>
            </div>
          </div>

          {/* Footer */}
          <div className="text-center text-sm text-muted-foreground border-t border-border pt-4">
            <p>Thank you for shopping with Xclusive Lifestyles!</p>
            <p className="mt-1">
              For queries: support@xclusivelifestyles.com | +91 98765 43210
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-3 print:hidden">
          <Button onClick={handlePrint} variant="luxury" className="flex-1">
            <Download className="mr-2 h-4 w-4" />
            Download Invoice
          </Button>
          <Button onClick={onClose} variant="outline">
            <X className="mr-2 h-4 w-4" />
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default InvoiceModal;
